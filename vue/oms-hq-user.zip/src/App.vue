<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script setup>
</script>

<style lang="scss">
#app {
  height: 100vh;
  margin: 0;
  padding: 0;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
</style>
