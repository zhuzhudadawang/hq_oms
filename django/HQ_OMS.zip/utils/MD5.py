from utils.password_encode import get_md5

print(get_md5('GC123456'))
print(get_md5('SC123456'))
print(get_md5('HQ123456'))
print(get_md5('123456'))

