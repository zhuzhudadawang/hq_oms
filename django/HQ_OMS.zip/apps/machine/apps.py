from django.apps import AppConfig


class MachineConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.machine"
